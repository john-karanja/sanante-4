<?php

require_once PHARMACARE_MEMBERSHIP_INC_PATH . '/general/register-template.php';
include_once PHARMACARE_MEMBERSHIP_INC_PATH . '/general/helper.php';